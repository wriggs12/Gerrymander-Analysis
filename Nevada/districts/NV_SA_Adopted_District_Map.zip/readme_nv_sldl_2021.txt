2021 Nevada State House map enacted 11/15/21

##Redistricting Data Hub (RDH) Retrieval Date
11/20/2021

##Sources
This dataset was retrieved from MyDistricting Nevada 2021 https://redistricting.leg.state.nv.us/legdistricting/nevada/comment_links#  

##Processing
The RDH retrieved the data from the source listed and did not modify any of the data.

##Additional Notes
To keep track of state's adopted maps, go to All About Redistricting https://redistricting.lls.edu/
For any additional questions, please email info@redistrictingdatahub.org